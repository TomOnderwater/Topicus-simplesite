let products = []
const host = location.host
const httpPrefix = isSecure() ? 'https://' : 'http://'
const spacing = 50

const texturePath = "assets/textures/"

let m

let receipt = []

let checkout = false, finishCheckoutButton

let trolleyicon, checkoutButton

let pMouseClicked = false, mouseClick = false

function setup() 
{
  canvas = createCanvas(windowWidth, windowHeight)

  background(255)
  finishCheckoutButton = createButton("checkout")

  loadProducts()
  trolleyicon = loadImage(texturePath + "cart.png")
  checkoutButton = new CheckoutButton()
}

function draw()
  {
    background(255)
    m = {x: mouseX, y: mouseY}
    checkoutButton.draw()
    if (!checkout)
    {
        let offset = 0
        for (let product of products)
        {
            let divHeight = product.draw(offset)
            offset += divHeight
        }
    }
    else
    {
        drawCheckout()
    }

    mouseClick = false
  }
  
function drawCheckout()
{
    let xOffset = 100
    let yOffset = 100
    receipt = []
    let total = 0
    for (let product of products)
    {
        if (product.selected)
            receipt.push(product.getProductInfo())
    }
    for (product of receipt)
    {
        push()
        text(product.quantity + " " + product.name, xOffset, yOffset)
        text("price: €" + product.price, xOffset + 100, yOffset)
        textStyle(BOLD)
        pop()
        yOffset += 30
        total += product.price * product.quantity
    }
    if (receipt.length > 0)
    {
        push()
        let totalTXT = "total: "
        textStyle(BOLD)
        let w = textWidth(totalTXT)
        text("total: ", xOffset + 200, yOffset)
        textStyle(NORMAL)
        text(total, xOffset + 200 + w, yOffset)
        pop()
        finishCheckoutButton.position(xOffset + 200, yOffset + 30)
        finishCheckoutButton.mousePressed(doCheckout)

    }
}

async function doCheckout()
{
    performCheckout(receipt)
    receipt = []
}

async function performCheckout(receipt)
{
    checkout = false
    finishCheckoutButton.hide()
    console.log(receipt)
    let data = await returnPost(httpPrefix + host + "/checkout", receipt)
    updateProducts(data)
}

class CheckoutButton
{
    constructor()
    {
        this.pos = {x: width - 40, y: 40}
        this.area = {x1: this.pos.x - 25, x2: this.pos.x + 25, y1: this.pos.y - 25, y2: this.pos.y + 25}
    }
    draw()
    {
        push()
        let opacity = 255
        if (onField(m, this.area)) 
        {
            opacity = 150
            if (mouseClick) 
                {
                    checkout = !checkout
                    if (checkout) finishCheckoutButton.show()
                    else finishCheckoutButton.hide()
                }
        }
        rectMode(CORNERS)
        fill(200, opacity)
        rect(this.area.x1, this.area.y1, this.area.x2, this.area.y2, 5)
        imageMode(CENTER)
        fill(opacity)
        image(trolleyicon, this.pos.x, this.pos.y, 40, 40)
        pop()
    }
}



class Product
{
    constructor(productinfo)
    {
        this.name = productinfo.name
        this.price = productinfo.price
        this.description = productinfo.description
        this.quantity = productinfo.quantity
        this.img = productinfo.img
        
        this.XStart = 20
        this.width = 500
        this.rounding = 5
        this.divHeight = spacing
        this.divOpen = false
        this.selected = 0
    }
    drawDefault(offset)
    {

        let area = {x1: this.XStart, y1: offset, x2: this.XStart + this.width, y2: offset + this.divHeight}
        let textY = area.y2 - 10
        push()
        fill(255)
        if (onField(m, area)) 
        {
            fill(230) // highlight color
            if (mouseClick) this.divOpen = !this.divOpen
        }
        rectMode(CORNERS)
        rect(area.x1, area.y1, area.x2, area.y2, this.rounding)
        fill(0)
        text(this.name, this.XStart + 100, textY)
        text("price: €" + this.price, area.x2 - 100, textY)
        imageMode(CENTER)
        image(this.img, this.XStart + 25, (area.y1 + area.y2) * 0.5, this.divHeight - 10, this.divHeight - 10)
        pop()

        return this.divHeight
    }
    drawDetails(offset)
    {
        let divHeight = this.divHeight * 3
        let area = {x1: this.XStart, y1: offset, x2: this.XStart + this.width, y2: offset + divHeight}
        push()
        rectMode(CORNERS)
        fill(255)
        if (onField(m, area)) fill(230)
        rect(area.x1, area.y1, area.x2, area.y2, this.rounding)
        let xBar = this.XStart + 150
        fill(0)
        textStyle(NORMAL)
        text(this.name, xBar, area.y1 + 20)
        textStyle(BOLD)
        text("product info: ", xBar, area.y1 + 40)
        textStyle(NORMAL)
        text(this.description, xBar, area.y1 + 60)
        textStyle(BOLD)
        text("price:", xBar, area.y1 + 80)
        textStyle(NORMAL)
        text("€ " + this.price, xBar, area.y1 + 100)
        textStyle(BOLD)
        text("products in stock:", xBar, area.y1 + 120)
        textStyle(NORMAL)
        text(this.quantity, xBar, area.y1 + 140)
        imageMode(CENTER)
        image(this.img, this.XStart + divHeight * 0.55, (area.y1 + area.y2) * 0.5, divHeight - 10, divHeight - 10)
        
        // shopping cart 
        let plusButton = new SimpleButton({x: area.x2 - 20, y: area.y2 - 20}, "+")
        let minusButton = new SimpleButton({x: area.x2 - 80, y: area.y2 - 20}, "-")
        let plusSelected = plusButton.draw()
        let minusSelected = minusButton.draw()
        textStyle(NORMAL)
        textAlign(CENTER, CENTER)
        fill(0)
        text(this.selected, (plusButton.pos.x + minusButton.pos.x) * 0.5, area.y2 - 20)

        if (mouseClick)
        {
            if (plusSelected) 
            {
                if (this.selected < this.quantity) this.selected ++
            }
            else if (minusSelected)
            {
                if (this.selected > 0) this.selected --
            }
            else if (onField(m, area))
            {
                if (mouseClick) this.divOpen = !this.divOpen
            }
        }
        
        pop()
        return divHeight
    }
    draw(offset)
    {   
        if (!this.divOpen) return this.drawDefault(offset)
        else return this.drawDetails(offset)
    }
    openClose()
    {
        if (!this.divOpen) this.openBox()
        else this.closeBox()
    }
    getProductInfo()
    {
        return {name: this.name, price: this.price, quantity: this.selected}
    }
}

class SimpleButton
{
    constructor(pos, icon)
    {
        this.pos = pos
        this.icon = icon
        this.area = {x1: this.pos.x - 10, y1: this.pos.y - 10, x2: this.pos.x + 10, y2: this.pos.y + 10}
    }
    draw()
    {
        let mouseOver = onField(m, this.area)
        push()
        fill(255, 0, 0)
        if (mouseOver)
        {
            fill(230, 50, 50)
        }
        rectMode(CORNERS)
        rect(this.area.x1, this.area.y1, this.area.x2, this.area.y2, 5)
        //rect
        fill(255)
        textAlign(CENTER, CENTER)
        textStyle(BOLD)
        textSize(20)
        text(this.icon, this.pos.x, this.pos.y)
        pop()
        return mouseOver
    }
}

function updateProducts(data)
{
    loadImages(data)
    products = []
    for (let product of data)
    {
        products.push(new Product(product))
    }
}

async function loadProducts()
{
    let data = await returnPost(httpPrefix + host + "/products", {})
    updateProducts(data)
}

function loadImages(products)
{
    products.forEach(product => product.img = loadImage(texturePath + product.image))
}

async function returnPost(url, data) {
    const body = JSON.stringify(data)
    console.log("data = ", body)
    const response = await fetch(url, {
      method: 'POST', // *GET, POST, PUT, DELETE, etc.
      mode: 'cors', // no-cors, *cors, same-origin
      cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
      credentials: 'include', // include, *same-origin, omit
      body,
      headers: {
        'Content-Type': 'application/json',
        //'Access-Control-Allow-Origin': '192.168.178.48',
        // 'Content-Type': 'application/x-www-form-urlencoded',
      }//,
      //body // body data type must match "Content-Type" header
    })
    if (response) return response.json()
    else return null
  }

  function onField(p, area)
{
    return (p.x > area.x1 && p.x < area.x2 && p.y > area.y1 && p.y < area.y2)
}

  function isSecure()
{
    if (location.protocol === 'https:') return true
    return false
}

function mousePressed()
{
    if (!pMouseClicked) 
    {
        mouseClick = true
        pMouseClicked = true
    }
    pMouseClicked = true
}

function mouseReleased()
{
    pMouseClicked = false
    mouseClick = false
}