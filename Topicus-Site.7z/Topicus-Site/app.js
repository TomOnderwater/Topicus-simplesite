const express = require("express")
const app = express()
const port = 8080

const ProductDatabase = require("./productDB.js")

app.use(express.static("public"))

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname + "/public/index.html"))
})

const server = app.listen(port, () => {
    console.log(`Topicus listening at http://localhost:${port}`)
  })

const DB = new ProductDatabase()

app.post("/checkout", (req, res) => {
    console.log('got a checkout request')
    let data = req.body
    console.log(data)
    if (data != undefined)
    {
        for (product of data)
        {
            DB.removeProduct(product.name, product.quantity)
        }
    }
    res.send(DB.getProducts())
})
app.post("/products", (req, res) => {
    console.log('got a request')
    let data = req.body
    res.send(DB.getProducts())
  })

