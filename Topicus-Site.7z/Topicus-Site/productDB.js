module.exports = class ProductDatabase 
{
    // placeholder for regular database connnection
    constructor()
    {
        this.products = 
        [
            {name: "Cola", price: 0.99, description: "A fresh sweet black beverage, totally on brand", quantity: 90, image: "colaicon.png"},
            {name: "Fanta", price: 0.89, description: "A fresh sweet citrus flavored beverage, totally on brand", quantity: 100, image: "fantaicon.png"},
        ]
    }
    getProducts()
    {
        return this.products
    }
    removeProduct(name, quantity)
    {
        const found = this.products.find((product) => product.name = name)
        if (found) found.quantity -= quantity
    }
}